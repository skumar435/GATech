Advanced
========
This will describe advanced methods. These are methods that are often called internally
and are exposed for completeness, but do not make up typical use cases.

.. autofunction:: phylotree.placenodes

.. autofunction:: phylotree.update

