Selection
=========
This will describe methods that pertain to making selections.

.. autofunction:: phylotree.modify_selection

.. autofunction:: phylotree.selection_callback

.. autofunction:: phylotree.selection_label

.. autofunction:: phylotree.get_selection

.. autofunction:: phylotree.select_all_descendants

